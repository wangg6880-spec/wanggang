#!/usr/bin/env bash
# 我的厨房 · 阿里云（Ubuntu 24.04）服务器初始化
# 用法：上传到服务器后执行  bash server-init-aliyun.sh
set -euo pipefail

echo "== 1/7 换阿里云 apt 源（大陆节点加速，香港节点可跳过）=="
if grep -qi "aliyun" /etc/os-release 2>/dev/null || grep -qi "aliyuncs" /etc/apt/sources.list 2>/dev/null; then
  echo "   已是阿里云源，跳过"
elif [ "${USE_ALIYUN_APT:-yes}" = "yes" ]; then
  sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak.$(date +%s) 2>/dev/null || true
  sudo sed -i 's|http://archive.ubuntu.com|http://mirrors.aliyun.com|g; s|http://security.ubuntu.com|http://mirrors.aliyun.com|g' /etc/apt/sources.list
fi

echo "== 2/7 更新系统 + 装基础软件 =="
sudo apt-get update -y
sudo apt-get install -y ca-certificates curl gnupg ufw nginx certbot python3-certbot-nginx

echo "== 3/7 安装 Docker =="
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sudo sh
fi
sudo systemctl enable --now docker
docker --version && docker compose version

echo "== 4/7 配置 Docker 镜像加速（阿里云容器镜像服务）=="
# 说明：加速器只对 Docker Hub 生效；Mealie 的镜像在 ghcr.io，见 README 的“拉不下镜像怎么办”
if [ -n "${ALIYUN_MIRROR:-}" ]; then
  sudo mkdir -p /etc/docker
  sudo tee /etc/docker/daemon.json >/dev/null <<EOF
{
  "registry-mirrors": ["${ALIYUN_MIRROR}"]
}
EOF
  sudo systemctl restart docker
  echo "   已配置加速器：${ALIYUN_MIRROR}"
else
  echo "   未设置 ALIYUN_MIRROR，跳过（可用：ALIYUN_MIRROR=https://你的ID.mirror.aliyuncs.com bash server-init-aliyun.sh）"
fi

echo "== 5/7 建目录 =="
sudo mkdir -p /opt/mealie/{data,custom-frontend,branding}
sudo chown -R "$USER":"$USER" /opt/mealie

echo "== 6/7 防火墙（系统层）=="
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable
sudo ufw status

echo "== 7/7 完成 =="
cat <<'EOF'
还需要在【阿里云控制台】放行端口：
  · 轻量应用服务器：实例 → 防火墙 → 添加规则 22/80/443
  · ECS：实例 → 安全组 → 配置规则 → 入方向 22/80/443

然后：
  1) 上传 docker-compose.yml、data-backup.tar.gz、custom-frontend.tar.gz、branding.tar.gz
  2) 解压到 /opt/mealie
  3) cd /opt/mealie && docker compose up -d
  4) 配 Nginx + HTTPS（见 README）
EOF
