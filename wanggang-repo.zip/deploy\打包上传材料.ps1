# 在【你自己的 Windows 电脑】上运行这个脚本，生成要传到服务器的两个压缩包
# 用法：右键 → 使用 PowerShell 运行；或在 PowerShell 里执行  .\打包上传材料.ps1

$ErrorActionPreference = "Stop"

$project = "C:\Users\jbw13\Documents\Codex\2026-10-15\vibe-coding-https-github-com-mealie"
$src     = Join-Path $project "mealie"
$outDir  = Join-Path $project "outputs\部署"

Write-Host "== 1/3 打包数据（数据库 + 菜谱图片 + 密钥） ==" -ForegroundColor Cyan
$dataOut = Join-Path $outDir "data-backup.tar.gz"
& "$env:SystemRoot\System32\tar.exe" -czf $dataOut -C $src data
Write-Host ("   已生成 " + $dataOut + "  (" + [math]::Round((Get-Item $dataOut).Length/1MB,1) + " MB)")

Write-Host "== 2/3 打包定制前端（自建页面 / 中文 / 主题） ==" -ForegroundColor Cyan
$frontOut = Join-Path $outDir "custom-frontend.tar.gz"
& "$env:SystemRoot\System32\tar.exe" -czf $frontOut -C (Join-Path $src "mealie") frontend
Write-Host ("   已生成 " + $frontOut + "  (" + [math]::Round((Get-Item $frontOut).Length/1MB,1) + " MB)")

Write-Host "== 3/3 打包站点图标 ==" -ForegroundColor Cyan
$brandOut = Join-Path $outDir "branding.tar.gz"
& "$env:SystemRoot\System32\tar.exe" -czf $brandOut -C $src branding
Write-Host ("   已生成 " + $brandOut)

Write-Host ""
Write-Host "下一步：把 outputs\部署 里的 3 个 .tar.gz + docker-compose.yml + nginx-mealie.conf 上传到服务器" -ForegroundColor Green
Write-Host "上传命令示例（在你电脑上执行，把 IP 换成你的服务器）：" -ForegroundColor Green
Write-Host "  scp `"$outDir\data-backup.tar.gz`" `"$outDir\custom-frontend.tar.gz`" `"$outDir\branding.tar.gz`" `"$outDir\docker-compose.yml`" root@服务器IP:/opt/mealie/"
