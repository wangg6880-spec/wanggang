#!/usr/bin/env bash
# 我的厨房 · 腾讯云 Ubuntu 服务器初始化
# 用法：上传到服务器后执行  bash server-init.sh
set -euo pipefail

echo "== 1/6 更新系统 =="
sudo apt-get update -y
sudo apt-get install -y ca-certificates curl gnupg ufw nginx certbot python3-certbot-nginx

echo "== 2/6 安装 Docker =="
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sudo sh
fi
sudo systemctl enable --now docker
docker --version
docker compose version

echo "== 3/6 建目录 =="
sudo mkdir -p /opt/mealie/{data,custom-frontend,branding}
sudo chown -R "$USER":"$USER" /opt/mealie

echo "== 4/6 防火墙（系统层）=="
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable
sudo ufw status

echo "== 5/6 提醒 =="
cat <<'EOF'
还需要在【腾讯云控制台 → 轻量应用服务器 → 防火墙】放行：
  22(SSH) / 80(HTTP) / 443(HTTPS)
如果备案还没下来，先临时放行 8080 端口做测试：
  然后访问 http://服务器IP:8080  （见 README 第 6 节）
EOF

echo "== 6/6 完成 =="
echo "下一步：把 docker-compose.yml / data / custom-frontend / branding 放到 /opt/mealie，然后 cd /opt/mealie && docker compose up -d"
